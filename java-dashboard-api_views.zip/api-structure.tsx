"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function ApiStructure() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Java Dashboard API Structure</h1>

      <Tabs defaultValue="overview">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="endpoints">API Endpoints</TabsTrigger>
          <TabsTrigger value="models">Data Models</TabsTrigger>
          <TabsTrigger value="services">Services</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>Project Structure</CardTitle>
              <CardDescription>Spring Boot application with SQL Server integration</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-md bg-muted p-4">
                  <pre className="text-sm">
                    <code>
                      {`src/
├── main/
│   ├── java/
│   │   └── com/
│   │       └── dashboard/
│   │           ├── DashboardApplication.java
│   │           ├── config/
│   │           │   ├── SecurityConfig.java
│   │           │   └── SwaggerConfig.java
│   │           ├── controller/
│   │           │   ├── DashboardController.java
│   │           │   ├── ReportController.java
│   │           │   └── UserController.java
│   │           ├── model/
│   │           │   ├── Dashboard.java
│   │           │   ├── Report.java
│   │           │   └── User.java
│   │           ├── repository/
│   │           │   ├── DashboardRepository.java
│   │           │   ├── ReportRepository.java
│   │           │   └── UserRepository.java
│   │           ├── service/
│   │           │   ├── DashboardService.java
│   │           │   ├── ReportService.java
│   │           │   └── UserService.java
│   │           └── util/
│   │               └── ReportGenerator.java
│   └── resources/
│       ├── application.properties
│       ├── schema.sql
│       └── data.sql
└── test/
    └── java/
        └── com/
            └── dashboard/
                ├── controller/
                ├── service/
                └── repository/`}
                    </code>
                  </pre>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Key Technologies</h3>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Spring Boot - Framework for building Java applications</li>
                    <li>Spring Data JPA - Data access layer</li>
                    <li>Spring Security - Authentication and authorization</li>
                    <li>SQL Server - Database</li>
                    <li>Swagger/OpenAPI - API documentation</li>
                    <li>JUnit & Mockito - Testing</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Configuration</h3>
                  <div className="rounded-md bg-muted p-4">
                    <pre className="text-sm">
                      <code>
                        {`# application.properties
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=dashboard
spring.datasource.username=sa
spring.datasource.password=YourPassword
spring.datasource.driverClassName=com.microsoft.sqlserver.jdbc.SQLServerDriver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.SQLServer2012Dialect

# JWT Configuration
jwt.secret=yourSecretKey
jwt.expiration=86400000

# Report Generation
report.output.path=/tmp/reports/
report.template.path=classpath:templates/reports/`}
                      </code>
                    </pre>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="endpoints">
          <Card>
            <CardHeader>
              <CardTitle>API Endpoints</CardTitle>
              <CardDescription>RESTful API endpoints for dashboard, reports, and user management</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Dashboard Endpoints</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@RestController
@RequestMapping("/api/dashboards")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping
    public List<Dashboard> getAllDashboards() {
        return dashboardService.findAll();
    }

    @GetMapping("/{id}")
    public Dashboard getDashboardById(@PathVariable Long id) {
        return dashboardService.findById(id);
    }

    @PostMapping
    public Dashboard createDashboard(@RequestBody Dashboard dashboard) {
        return dashboardService.save(dashboard);
    }

    @PutMapping("/{id}")
    public Dashboard updateDashboard(@PathVariable Long id, @RequestBody Dashboard dashboard) {
        dashboard.setId(id);
        return dashboardService.update(dashboard);
    }

    @DeleteMapping("/{id}")
    public void deleteDashboard(@PathVariable Long id) {
        dashboardService.deleteById(id);
    }

    @GetMapping("/{id}/widgets")
    public List<Widget> getDashboardWidgets(@PathVariable Long id) {
        return dashboardService.findWidgetsByDashboardId(id);
    }

    @PostMapping("/{id}/widgets")
    public Widget addWidgetToDashboard(@PathVariable Long id, @RequestBody Widget widget) {
        return dashboardService.addWidget(id, widget);
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Report Endpoints</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping
    public List<Report> getAllReports() {
        return reportService.findAll();
    }

    @GetMapping("/{id}")
    public Report getReportById(@PathVariable Long id) {
        return reportService.findById(id);
    }

    @PostMapping
    public Report createReport(@RequestBody Report report) {
        return reportService.save(report);
    }

    @PutMapping("/{id}")
    public Report updateReport(@PathVariable Long id, @RequestBody Report report) {
        report.setId(id);
        return reportService.update(report);
    }

    @DeleteMapping("/{id}")
    public void deleteReport(@PathVariable Long id) {
        reportService.deleteById(id);
    }

    @GetMapping("/{id}/generate")
    public ResponseEntity<Resource> generateReport(@PathVariable Long id, 
                                                 @RequestParam(required = false) String format) {
        Resource reportFile = reportService.generateReport(id, format);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, 
                        "attachment; filename=\"" + reportFile.getFilename() + "\"")
                .body(reportFile);
    }

    @GetMapping("/types")
    public List<String> getReportTypes() {
        return reportService.getAvailableReportTypes();
    }

    @PostMapping("/schedule")
    public ScheduledReport scheduleReport(@RequestBody ScheduleRequest request) {
        return reportService.scheduleReport(request);
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">User Management Endpoints</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    public List<User> getAllUsers() {
        return userService.findAll();
    }

    @GetMapping("/{id}")
    public User getUserById(@PathVariable Long id) {
        return userService.findById(id);
    }

    @PostMapping
    public User createUser(@RequestBody User user) {
        return userService.save(user);
    }

    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody User user) {
        user.setId(id);
        return userService.update(user);
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteById(id);
    }

    @PostMapping("/{id}/roles")
    public User assignRolesToUser(@PathVariable Long id, @RequestBody List<Role> roles) {
        return userService.assignRoles(id, roles);
    }

    @GetMapping("/{id}/dashboards")
    public List<Dashboard> getUserDashboards(@PathVariable Long id) {
        return userService.findDashboardsByUserId(id);
    }

    @GetMapping("/{id}/reports")
    public List<Report> getUserReports(@PathVariable Long id) {
        return userService.findReportsByUserId(id);
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Authentication Endpoints</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenProvider tokenProvider;

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                loginRequest.getUsername(),
                loginRequest.getPassword()
            )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = tokenProvider.generateToken(authentication);
        
        return ResponseEntity.ok(new JwtAuthenticationResponse(jwt));
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody SignUpRequest signUpRequest) {
        if (userService.existsByUsername(signUpRequest.getUsername())) {
            return ResponseEntity.badRequest().body("Username is already taken!");
        }

        if (userService.existsByEmail(signUpRequest.getEmail())) {
            return ResponseEntity.badRequest().body("Email is already in use!");
        }

        User user = new User(
            signUpRequest.getName(),
            signUpRequest.getUsername(),
            signUpRequest.getEmail(),
            signUpRequest.getPassword()
        );

        userService.save(user);

        return ResponseEntity.ok("User registered successfully");
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="models">
          <Card>
            <CardHeader>
              <CardTitle>Data Models</CardTitle>
              <CardDescription>Entity classes for database tables</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">User Model</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@Entity
@Table(name = "users")
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(nullable = false, unique = true)
    private String username;
    
    @Column(nullable = false, unique = true)
    private String email;
    
    @Column(nullable = false)
    private String password;
    
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "user_roles",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Dashboard> dashboards;
    
    @OneToMany(mappedBy = "creator", cascade = CascadeType.ALL)
    private List<Report> reports;
    
    // Constructors, getters, setters
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Dashboard Model</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@Entity
@Table(name = "dashboards")
public class Dashboard {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(length = 1000)
    private String description;
    
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @OneToMany(mappedBy = "dashboard", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Widget> widgets = new ArrayList<>();
    
    @Column(name = "layout_config", columnDefinition = "TEXT")
    private String layoutConfig;
    
    @Column(name = "is_public")
    private boolean isPublic = false;
    
    // Constructors, getters, setters
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Report Model</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@Entity
@Table(name = "reports")
public class Report {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(length = 1000)
    private String description;
    
    @Column(name = "report_type", nullable = false)
    private String reportType;
    
    @Column(name = "query_params", columnDefinition = "TEXT")
    private String queryParams;
    
    @ManyToOne
    @JoinColumn(name = "creator_id", nullable = false)
    private User creator;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @Column(name = "last_run_at")
    private LocalDateTime lastRunAt;
    
    @Column(name = "schedule_cron")
    private String scheduleCron;
    
    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private ReportStatus status;
    
    @OneToMany(mappedBy = "report", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ReportExecution> executions = new ArrayList<>();
    
    // Constructors, getters, setters
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Widget Model</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@Entity
@Table(name = "widgets")
public class Widget {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String title;
    
    @Column(name = "widget_type", nullable = false)
    private String widgetType;
    
    @Column(name = "data_source", nullable = false)
    private String dataSource;
    
    @Column(name = "query_params", columnDefinition = "TEXT")
    private String queryParams;
    
    @Column(name = "visual_config", columnDefinition = "TEXT")
    private String visualConfig;
    
    @ManyToOne
    @JoinColumn(name = "dashboard_id", nullable = false)
    private Dashboard dashboard;
    
    @Column(name = "position_x")
    private Integer positionX;
    
    @Column(name = "position_y")
    private Integer positionY;
    
    @Column(name = "width")
    private Integer width;
    
    @Column(name = "height")
    private Integer height;
    
    @Column(name = "refresh_interval")
    private Integer refreshInterval;
    
    // Constructors, getters, setters
}`}
                        </code>
                      </pre>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="services">
          <Card>
            <CardHeader>
              <CardTitle>Service Layer</CardTitle>
              <CardDescription>Business logic implementation</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Report Service</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private ReportRepository reportRepository;
    
    @Autowired
    private ReportExecutionRepository executionRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ReportGenerator reportGenerator;
    
    @Autowired
    private SchedulerService schedulerService;
    
    @Override
    public List<Report> findAll() {
        return reportRepository.findAll();
    }
    
    @Override
    public Report findById(Long id) {
        return reportRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Report not found with id: " + id));
    }
    
    @Override
    public List<Report> findByCreatorId(Long creatorId) {
        return reportRepository.findByCreatorId(creatorId);
    }
    
    @Override
    public Report save(Report report) {
        User creator = userRepository.findById(report.getCreator().getId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        report.setCreator(creator);
        report.setCreatedAt(LocalDateTime.now());
        report.setUpdatedAt(LocalDateTime.now());
        report.setStatus(ReportStatus.READY);
        
        Report savedReport = reportRepository.save(report);
        
        // Schedule the report if it has a cron expression
        if (savedReport.getScheduleCron() != null && !savedReport.getScheduleCron().isEmpty()) {
            schedulerService.scheduleReport(savedReport);
        }
        
        return savedReport;
    }
    
    @Override
    public Report update(Report report) {
        Report existingReport = findById(report.getId());
        
        existingReport.setName(report.getName());
        existingReport.setDescription(report.getDescription());
        existingReport.setQueryParams(report.getQueryParams());
        existingReport.setUpdatedAt(LocalDateTime.now());
        
        // Update schedule if changed
        if (!Objects.equals(existingReport.getScheduleCron(), report.getScheduleCron())) {
            if (existingReport.getScheduleCron() != null) {
                schedulerService.unscheduleReport(existingReport.getId());
            }
            
            existingReport.setScheduleCron(report.getScheduleCron());
            
            if (report.getScheduleCron() != null && !report.getScheduleCron().isEmpty()) {
                schedulerService.scheduleReport(existingReport);
            }
        }
        
        return reportRepository.save(existingReport);
    }
    
    @Override
    public void deleteById(Long id) {
        Report report = findById(id);
        
        // Unschedule if scheduled
        if (report.getScheduleCron() != null) {
            schedulerService.unscheduleReport(id);
        }
        
        reportRepository.deleteById(id);
    }
    
    @Override
    public Resource generateReport(Long id, String format) {
        Report report = findById(id);
        
        // Create execution record
        ReportExecution execution = new ReportExecution();
        execution.setReport(report);
        execution.setStartTime(LocalDateTime.now());
        execution.setStatus(ExecutionStatus.RUNNING);
        execution = executionRepository.save(execution);
        
        try {
            // Generate the report
            Resource reportFile = reportGenerator.generate(report, format != null ? format : "PDF");
            
            // Update report and execution
            report.setLastRunAt(LocalDateTime.now());
            report.setStatus(ReportStatus.READY);
            reportRepository.save(report);
            
            execution.setEndTime(LocalDateTime.now());
            execution.setStatus(ExecutionStatus.COMPLETED);
            execution.setOutputPath(reportFile.getURI().getPath());
            executionRepository.save(execution);
            
            return reportFile;
        } catch (Exception e) {
            // Handle failure
            report.setStatus(ReportStatus.ERROR);
            reportRepository.save(report);
            
            execution.setEndTime(LocalDateTime.now());
            execution.setStatus(ExecutionStatus.FAILED);
            execution.setErrorMessage(e.getMessage());
            executionRepository.save(execution);
            
            throw new ReportGenerationException("Failed to generate report: " + e.getMessage(), e);
        }
    }
    
    @Override
    public List<String> getAvailableReportTypes() {
        return Arrays.asList("Sales", "User Activity", "Performance", "Inventory", "Custom");
    }
    
    @Override
    public ScheduledReport scheduleReport(ScheduleRequest request) {
        Report report = findById(request.getReportId());
        report.setScheduleCron(request.getCronExpression());
        report = update(report);
        
        return new ScheduledReport(report.getId(), report.getName(), report.getScheduleCron());
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Dashboard Service</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`@Service
public class DashboardServiceImpl implements DashboardService {

    @Autowired
    private DashboardRepository dashboardRepository;
    
    @Autowired
    private WidgetRepository widgetRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Override
    public List<Dashboard> findAll() {
        return dashboardRepository.findAll();
    }
    
    @Override
    public Dashboard findById(Long id) {
        return dashboardRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dashboard not found with id: " + id));
    }
    
    @Override
    public List<Dashboard> findByUserId(Long userId) {
        return dashboardRepository.findByUserId(userId);
    }
    
    @Override
    public Dashboard save(Dashboard dashboard) {
        User user = userRepository.findById(dashboard.getUser().getId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        dashboard.setUser(user);
        dashboard.setCreatedAt(LocalDateTime.now());
        dashboard.setUpdatedAt(LocalDateTime.now());
        
        return dashboardRepository.save(dashboard);
    }
    
    @Override
    public Dashboard update(Dashboard dashboard) {
        Dashboard existingDashboard = findById(dashboard.getId());
        
        existingDashboard.setName(dashboard.getName());
        existingDashboard.setDescription(dashboard.getDescription());
        existingDashboard.setLayoutConfig(dashboard.getLayoutConfig());
        existingDashboard.setPublic(dashboard.isPublic());
        existingDashboard.setUpdatedAt(LocalDateTime.now());
        
        return dashboardRepository.save(existingDashboard);
    }
    
    @Override
    public void deleteById(Long id) {
        dashboardRepository.deleteById(id);
    }
    
    @Override
    public List<Widget> findWidgetsByDashboardId(Long dashboardId) {
        Dashboard dashboard = findById(dashboardId);
        return dashboard.getWidgets();
    }
    
    @Override
    public Widget addWidget(Long dashboardId, Widget widget) {
        Dashboard dashboard = findById(dashboardId);
        widget.setDashboard(dashboard);
        
        Widget savedWidget = widgetRepository.save(widget);
        dashboard.getWidgets().add(savedWidget);
        dashboardRepository.save(dashboard);
        
        return savedWidget;
    }
    
    @Override
    public void removeWidget(Long dashboardId, Long widgetId) {
        Dashboard dashboard = findById(dashboardId);
        Widget widget = widgetRepository.findById(widgetId)
                .orElseThrow(() -> new ResourceNotFoundException("Widget not found"));
        
        if (!widget.getDashboard().getId().equals(dashboardId)) {
            throw new IllegalArgumentException("Widget does not belong to this dashboard");
        }
        
        dashboard.getWidgets().remove(widget);
        dashboardRepository.save(dashboard);
        widgetRepository.delete(widget);
    }
    
    @Override
    public Dashboard clone(Long id, Long userId) {
        Dashboard original = findById(id);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        
        // Create new dashboard
        Dashboard clone = new Dashboard();
        clone.setName(original.getName() + " (Copy)");
        clone.setDescription(original.getDescription());
        clone.setLayoutConfig(original.getLayoutConfig());
        clone.setUser(user);
        clone.setCreatedAt(LocalDateTime.now());
        clone.setUpdatedAt(LocalDateTime.now());
        clone.setPublic(false);
        
        Dashboard savedClone = dashboardRepository.save(clone);
        
        // Clone widgets
        for (Widget originalWidget : original.getWidgets()) {
            Widget widgetClone = new Widget();
            widgetClone.setTitle(originalWidget.getTitle());
            widgetClone.setWidgetType(originalWidget.getWidgetType());
            widgetClone.setDataSource(originalWidget.getDataSource());
            widgetClone.setQueryParams(originalWidget.getQueryParams());
            widgetClone.setVisualConfig(originalWidget.getVisualConfig());
            widgetClone.setPositionX(originalWidget.getPositionX());
            widgetClone.setPositionY(originalWidget.getPositionY());
            widgetClone.setWidth(originalWidget.getWidth());
            widgetClone.setHeight(originalWidget.getHeight());
            widgetClone.setRefreshInterval(originalWidget.getRefreshInterval());
            widgetClone.setDashboard(savedClone);
            
            widgetRepository.save(widgetClone);
        }
        
        return findById(savedClone.getId());
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

