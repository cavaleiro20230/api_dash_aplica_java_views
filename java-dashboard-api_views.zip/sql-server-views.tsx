"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function SqlServerViews() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Integração com Views do SQL Server</h1>

      <Tabs defaultValue="views">
        <TabsList className="mb-4">
          <TabsTrigger value="views">Views SQL</TabsTrigger>
          <TabsTrigger value="repository">Repositórios</TabsTrigger>
          <TabsTrigger value="service">Serviços</TabsTrigger>
          <TabsTrigger value="config">Configuração</TabsTrigger>
        </TabsList>

        <TabsContent value="views">
          <Card>
            <CardHeader>
              <CardTitle>Views SQL Server</CardTitle>
              <CardDescription>Exemplos de views que podem ser usadas para relatórios e dashboards</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">View de Vendas Mensais</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`-- View para relatório de vendas mensais
CREATE VIEW vw_VendasMensais AS
SELECT 
    YEAR(DataVenda) AS Ano,
    MONTH(DataVenda) AS Mes,
    SUM(ValorTotal) AS TotalVendas,
    COUNT(DISTINCT IdCliente) AS TotalClientes,
    AVG(ValorTotal) AS MediaVendas
FROM 
    Vendas
GROUP BY 
    YEAR(DataVenda), MONTH(DataVenda);`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">View de Desempenho de Usuários</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`-- View para relatório de desempenho de usuários
CREATE VIEW vw_DesempenhoUsuarios AS
SELECT 
    u.Id AS IdUsuario,
    u.Nome,
    u.Departamento,
    COUNT(a.Id) AS TotalAcoes,
    MAX(a.DataHora) AS UltimaAtividade,
    SUM(CASE WHEN a.TipoAcao = 'Venda' THEN 1 ELSE 0 END) AS TotalVendas,
    SUM(CASE WHEN a.TipoAcao = 'Suporte' THEN 1 ELSE 0 END) AS TotalSuporte
FROM 
    Usuarios u
LEFT JOIN 
    Atividades a ON u.Id = a.IdUsuario
WHERE 
    a.DataHora >= DATEADD(month, -3, GETDATE())
GROUP BY 
    u.Id, u.Nome, u.Departamento;`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">View de Indicadores de Desempenho</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`-- View para KPIs do dashboard
CREATE VIEW vw_KPIs AS
SELECT 
    (SELECT COUNT(*) FROM Usuarios WHERE Ativo = 1) AS TotalUsuariosAtivos,
    (SELECT COUNT(*) FROM Relatorios) AS TotalRelatorios,
    (SELECT SUM(TotalRegistros) FROM Relatorios) AS TotalRegistrosProcessados,
    (SELECT COUNT(*) FROM Acessos WHERE DataAcesso >= DATEADD(day, -1, GETDATE())) AS AcessosUltimas24h,
    (SELECT AVG(TempoProcessamento) FROM Relatorios WHERE DataCriacao >= DATEADD(month, -1, GETDATE())) AS TempoMedioProcessamento;`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">View de Dados Geográficos</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`-- View para relatório geográfico
CREATE VIEW vw_DadosGeograficos AS
SELECT 
    r.Nome AS Regiao,
    e.Nome AS Estado,
    c.Nome AS Cidade,
    COUNT(v.Id) AS TotalVendas,
    SUM(v.ValorTotal) AS ValorTotal
FROM 
    Vendas v
JOIN 
    Clientes cl ON v.IdCliente = cl.Id
JOIN 
    Cidades c ON cl.IdCidade = c.Id
JOIN 
    Estados e ON c.IdEstado = e.Id
JOIN 
    Regioes r ON e.IdRegiao = r.Id
WHERE 
    v.DataVenda >= DATEADD(year, -1, GETDATE())
GROUP BY 
    r.Nome, e.Nome, c.Nome;`}
                        </code>
                      </pre>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="repository">
          <Card>
            <CardHeader>
              <CardTitle>Repositórios para Views</CardTitle>
              <CardDescription>Implementação de repositórios que acessam views do SQL Server</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Interface de Repositório para View</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`package com.dashboard.repository;

import com.dashboard.model.VendaMensal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VendaMensalRepository {
    
    @Query(value = "SELECT * FROM vw_VendasMensais WHERE Ano = ?1 ORDER BY Mes", nativeQuery = true)
    List<VendaMensal> findByAno(int ano);
    
    @Query(value = "SELECT * FROM vw_VendasMensais WHERE Ano = ?1 AND Mes = ?2", nativeQuery = true)
    VendaMensal findByAnoEMes(int ano, int mes);
    
    @Query(value = "SELECT * FROM vw_VendasMensais ORDER BY Ano DESC, Mes DESC", nativeQuery = true)
    List<VendaMensal> findAllOrderByDataDesc();
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Modelo para View</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`package com.dashboard.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "vw_VendasMensais")
@IdClass(VendaMensalId.class)
public class VendaMensal {
    
    @Id
    private Integer ano;
    
    @Id
    private Integer mes;
    
    private BigDecimal totalVendas;
    private Integer totalClientes;
    private BigDecimal mediaVendas;
    
    // Getters e setters
}

// Classe para chave composta
class VendaMensalId implements Serializable {
    private Integer ano;
    private Integer mes;
    
    // Construtores, equals, hashCode
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Repositório para KPIs</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`package com.dashboard.repository;

import com.dashboard.model.KPI;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface KPIRepository {
    
    @Query(value = "SELECT * FROM vw_KPIs", nativeQuery = true)
    KPI getKPIs();
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Repositório com Consulta Dinâmica</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`package com.dashboard.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class DynamicReportRepository {
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    /**
     * Executa uma consulta dinâmica em uma view
     * @param viewName Nome da view
     * @param filters Filtros a serem aplicados
     * @return Lista de resultados
     */
    public List<Map<String, Object>> executeViewQuery(String viewName, Map<String, Object> filters) {
        StringBuilder query = new StringBuilder("SELECT * FROM ");
        query.append(viewName);
        
        if (filters != null && !filters.isEmpty()) {
            query.append(" WHERE ");
            
            boolean first = true;
            for (Map.Entry<String, Object> entry : filters.entrySet()) {
                if (!first) {
                    query.append(" AND ");
                }
                query.append(entry.getKey()).append(" = ?");
                first = false;
            }
        }
        
        return jdbcTemplate.queryForList(query.toString(), filters.values().toArray());
    }
    
    /**
     * Executa uma consulta SQL personalizada
     * @param sql Consulta SQL
     * @param params Parâmetros da consulta
     * @return Lista de resultados
     */
    public List<Map<String, Object>> executeCustomQuery(String sql, Object[] params) {
        return jdbcTemplate.queryForList(sql, params);
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="service">
          <Card>
            <CardHeader>
              <CardTitle>Serviços para Relatórios</CardTitle>
              <CardDescription>Implementação de serviços que utilizam views para relatórios</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Serviço de Relatório de Vendas</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`package com.dashboard.service;

import com.dashboard.model.VendaMensal;
import com.dashboard.repository.VendaMensalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class RelatorioVendasService {
    
    @Autowired
    private VendaMensalRepository vendaMensalRepository;
    
    @Autowired
    private DynamicReportRepository dynamicReportRepository;
    
    /**
     * Obtém relatório de vendas mensais por ano
     */
    public List<VendaMensal> getVendasPorAno(int ano) {
        return vendaMensalRepository.findByAno(ano);
    }
    
    /**
     * Obtém dados para gráfico de vendas dos últimos 12 meses
     */
    public Map<String, Object> getDadosGraficoVendas() {
        List<VendaMensal> vendas = vendaMensalRepository.findAllOrderByDataDesc();
        
        // Limitar aos últimos 12 meses
        if (vendas.size() > 12) {
            vendas = vendas.subList(0, 12);
        }
        
        // Formatar dados para o gráfico
        List<String> labels = vendas.stream()
                .map(v -> v.getMes() + "/" + v.getAno())
                .collect(Collectors.toList());
        
        List<Double> valores = vendas.stream()
                .map(v -> v.getTotalVendas().doubleValue())
                .collect(Collectors.toList());
        
        Map<String, Object> resultado = Map.of(
                "labels", labels,
                "valores", valores,
                "titulo", "Vendas dos Últimos 12 Meses"
        );
        
        return resultado;
    }
    
    /**
     * Executa relatório personalizado com base em uma view
     */
    public List<Map<String, Object>> executarRelatorioPersonalizado(String viewName, Map<String, Object> filtros) {
        return dynamicReportRepository.executeViewQuery(viewName, filtros);
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Serviço de Dashboard</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`package com.dashboard.service;

import com.dashboard.model.KPI;
import com.dashboard.repository.DynamicReportRepository;
import com.dashboard.repository.KPIRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DashboardService {
    
    @Autowired
    private KPIRepository kpiRepository;
    
    @Autowired
    private DynamicReportRepository dynamicReportRepository;
    
    /**
     * Obtém os KPIs principais para o dashboard
     */
    public KPI getKPIs() {
        return kpiRepository.getKPIs();
    }
    
    /**
     * Obtém dados para widget de mapa de vendas por região
     */
    public List<Map<String, Object>> getDadosMapaVendas() {
        return dynamicReportRepository.executeViewQuery("vw_DadosGeograficos", new HashMap<>());
    }
    
    /**
     * Obtém dados para widget de desempenho de usuários
     */
    public List<Map<String, Object>> getDesempenhoUsuarios(String departamento) {
        Map<String, Object> filtros = new HashMap<>();
        
        if (departamento != null && !departamento.isEmpty()) {
            filtros.put("Departamento", departamento);
        }
        
        return dynamicReportRepository.executeViewQuery("vw_DesempenhoUsuarios", filtros);
    }
    
    /**
     * Obtém dados para widget personalizado com base em SQL
     */
    public List<Map<String, Object>> getDadosWidgetPersonalizado(String sql, Object[] params) {
        return dynamicReportRepository.executeCustomQuery(sql, params);
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="config">
          <Card>
            <CardHeader>
              <CardTitle>Configuração do SQL Server</CardTitle>
              <CardDescription>Configurações para conexão com SQL Server e uso de views</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Configuração de Conexão</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`# application.properties

# Configuração de conexão com SQL Server
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=dashboard
spring.datasource.username=sa
spring.datasource.password=YourPassword
spring.datasource.driverClassName=com.microsoft.sqlserver.jdbc.SQLServerDriver

# Configurações JPA
spring.jpa.hibernate.ddl-auto=none
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.SQLServer2012Dialect

# Importante: Configuração para permitir mapeamento de views
spring.jpa.hibernate.naming.physical-strategy=org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl
spring.jpa.properties.hibernate.globally_quoted_identifiers=true`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Configuração de DataSource</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`package com.dashboard.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {

    @Autowired
    private Environment env;

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(env.getProperty("spring.datasource.driverClassName"));
        dataSource.setUrl(env.getProperty("spring.datasource.url"));
        dataSource.setUsername(env.getProperty("spring.datasource.username"));
        dataSource.setPassword(env.getProperty("spring.datasource.password"));
        return dataSource;
    }
    
    @Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Configuração de Cache para Views</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`package com.dashboard.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableCaching
public class CacheConfig {

    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("views", "reports", "kpis");
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Exemplo de Controller usando Views</h3>
                    <div className="rounded-md bg-muted p-4">
                      <pre className="text-sm">
                        <code>
                          {`package com.dashboard.controller;

import com.dashboard.model.KPI;
import com.dashboard.model.VendaMensal;
import com.dashboard.service.DashboardService;
import com.dashboard.service.RelatorioVendasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;
    
    @Autowired
    private RelatorioVendasService relatorioVendasService;

    @GetMapping("/kpis")
    public ResponseEntity<KPI> getKPIs() {
        return ResponseEntity.ok(dashboardService.getKPIs());
    }
    
    @GetMapping("/vendas/{ano}")
    public ResponseEntity<List<VendaMensal>> getVendasPorAno(@PathVariable int ano) {
        return ResponseEntity.ok(relatorioVendasService.getVendasPorAno(ano));
    }
    
    @GetMapping("/grafico-vendas")
    public ResponseEntity<Map<String, Object>> getGraficoVendas() {
        return ResponseEntity.ok(relatorioVendasService.getDadosGraficoVendas());
    }
    
    @GetMapping("/mapa-vendas")
    public ResponseEntity<List<Map<String, Object>>> getMapaVendas() {
        return ResponseEntity.ok(dashboardService.getDadosMapaVendas());
    }
    
    @GetMapping("/desempenho-usuarios")
    public ResponseEntity<List<Map<String, Object>>> getDesempenhoUsuarios(
            @RequestParam(required = false) String departamento) {
        return ResponseEntity.ok(dashboardService.getDesempenhoUsuarios(departamento));
    }
    
    @PostMapping("/relatorio-personalizado")
    public ResponseEntity<List<Map<String, Object>>> getRelatorioPersonalizado(
            @RequestParam String viewName,
            @RequestBody(required = false) Map<String, Object> filtros) {
        if (filtros == null) {
            filtros = new HashMap<>();
        }
        return ResponseEntity.ok(relatorioVendasService.executarRelatorioPersonalizado(viewName, filtros));
    }
}`}
                        </code>
                      </pre>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

